<a href="/">
    <img src="/storage/logo/logo.png" alt="Logo de la aplicación" style="height: 100px">
</a>
<?php /**PATH C:\Users\hugom\Documents\DWES-Hugo-Moruno\Laravel\aprende03\proyectos\ConcesionarioApp\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>