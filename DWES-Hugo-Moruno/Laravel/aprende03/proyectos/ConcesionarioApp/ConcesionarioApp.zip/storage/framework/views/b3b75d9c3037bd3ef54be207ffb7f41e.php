<div class="flex justify-between my-3">
    <h3 class="text-lg font-bold mb-4">Lista de Clientes</h3>
    <a href="<?php echo e(route('admin.clientes.index')); ?>">
        <?php if (isset($component)) { $__componentOriginald148e865c5ac24c5be2edcd9c222cd9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald148e865c5ac24c5be2edcd9c222cd9d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.button-edit','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buttons.button-edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald148e865c5ac24c5be2edcd9c222cd9d)): ?>
<?php $attributes = $__attributesOriginald148e865c5ac24c5be2edcd9c222cd9d; ?>
<?php unset($__attributesOriginald148e865c5ac24c5be2edcd9c222cd9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald148e865c5ac24c5be2edcd9c222cd9d)): ?>
<?php $component = $__componentOriginald148e865c5ac24c5be2edcd9c222cd9d; ?>
<?php unset($__componentOriginald148e865c5ac24c5be2edcd9c222cd9d); ?>
<?php endif; ?>
    </a>

</div>
<?php if($clientes->isEmpty()): ?>
    <p>No hay clientes registrados.</p>
<?php else: ?>
    <table class="table-auto w-full border-collapse border border-gray-300">
        <thead>
        <tr class="bg-gray-100">
            <th class="border border-gray-300 px-4 py-2">ID</th>
            <th class="border border-gray-300 px-4 py-2">Nombre</th>
            <th class="border border-gray-300 px-4 py-2">Email</th>
            <th class="border border-gray-300 px-4 py-2">Teléfono</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border border-gray-300">
                <td class="px-4 py-2 text-center"><?php echo e($cliente->id); ?></td>
                <td class="px-4 py-2"><?php echo e($cliente->nombre); ?></td>
                <td class="px-4 py-2"><?php echo e($cliente->email); ?></td>
                <td class="px-4 py-2"><?php echo e($cliente->telefono ?? 'N/A'); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php endif; ?>
<?php /**PATH C:\Users\hugom\Documents\DWES-Hugo-Moruno\Laravel\aprende03\proyectos\ConcesionarioApp\resources\views/admin/clientes/partials/list.blade.php ENDPATH**/ ?>