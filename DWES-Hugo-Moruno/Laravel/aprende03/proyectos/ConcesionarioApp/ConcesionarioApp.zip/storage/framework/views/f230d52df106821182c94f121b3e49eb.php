<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['modelo' => null, 'submit' => true, 'readonly' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['modelo' => null, 'submit' => true, 'readonly' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="mx-auto px-8">
    <div class="w-full border p-2 bg-white shadow-lg rounded-lg grid grid-cols-12 gap-2">
        <div class="col-span-12 p-1 bg-gray-300 uppercase tracking-widest font-semibold text-lg text-center">
            <?php echo e($modelo?->nombre ?? 'Registra un Modelo'); ?>

        </div>

        <!-- Identificador -->
        <div class="col-span-12 md:col-span-6">
            <?php if (isset($component)) { $__componentOriginale5c175f804af24f9bffe6a91552355f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale5c175f804af24f9bffe6a91552355f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.input-text-label','data' => ['id' => 'identificador','name' => 'identificador','label' => 'Identificador','item' => $modelo?->identificador,'readonly' => ''.e($readonly).'','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('inputs.input-text-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'identificador','name' => 'identificador','label' => 'Identificador','item' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($modelo?->identificador),'readonly' => ''.e($readonly).'','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale5c175f804af24f9bffe6a91552355f3)): ?>
<?php $attributes = $__attributesOriginale5c175f804af24f9bffe6a91552355f3; ?>
<?php unset($__attributesOriginale5c175f804af24f9bffe6a91552355f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale5c175f804af24f9bffe6a91552355f3)): ?>
<?php $component = $__componentOriginale5c175f804af24f9bffe6a91552355f3; ?>
<?php unset($__componentOriginale5c175f804af24f9bffe6a91552355f3); ?>
<?php endif; ?>
        </div>

        <!-- Nombre -->
        <div class="col-span-12 md:col-span-6">
            <?php if (isset($component)) { $__componentOriginale5c175f804af24f9bffe6a91552355f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale5c175f804af24f9bffe6a91552355f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.input-text-label','data' => ['id' => 'nombre','name' => 'nombre','label' => 'Nombre','item' => $modelo?->nombre,'readonly' => ''.e($readonly).'','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('inputs.input-text-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'nombre','name' => 'nombre','label' => 'Nombre','item' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($modelo?->nombre),'readonly' => ''.e($readonly).'','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale5c175f804af24f9bffe6a91552355f3)): ?>
<?php $attributes = $__attributesOriginale5c175f804af24f9bffe6a91552355f3; ?>
<?php unset($__attributesOriginale5c175f804af24f9bffe6a91552355f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale5c175f804af24f9bffe6a91552355f3)): ?>
<?php $component = $__componentOriginale5c175f804af24f9bffe6a91552355f3; ?>
<?php unset($__componentOriginale5c175f804af24f9bffe6a91552355f3); ?>
<?php endif; ?>
        </div>

        <!-- Tipo -->
        <div class="col-span-12 md:col-span-6">
            <?php if (isset($component)) { $__componentOriginale5c175f804af24f9bffe6a91552355f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale5c175f804af24f9bffe6a91552355f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.input-text-label','data' => ['id' => 'tipo','name' => 'tipo','label' => 'Tipo','item' => $modelo?->tipo,'readonly' => ''.e($readonly).'','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('inputs.input-text-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'tipo','name' => 'tipo','label' => 'Tipo','item' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($modelo?->tipo),'readonly' => ''.e($readonly).'','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale5c175f804af24f9bffe6a91552355f3)): ?>
<?php $attributes = $__attributesOriginale5c175f804af24f9bffe6a91552355f3; ?>
<?php unset($__attributesOriginale5c175f804af24f9bffe6a91552355f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale5c175f804af24f9bffe6a91552355f3)): ?>
<?php $component = $__componentOriginale5c175f804af24f9bffe6a91552355f3; ?>
<?php unset($__componentOriginale5c175f804af24f9bffe6a91552355f3); ?>
<?php endif; ?>
        </div>

        <!-- Año -->
        <div class="col-span-12 md:col-span-6">
            <?php if (isset($component)) { $__componentOriginale5c175f804af24f9bffe6a91552355f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale5c175f804af24f9bffe6a91552355f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.input-text-label','data' => ['id' => 'anho','name' => 'anho','label' => 'Año','item' => $modelo?->anho,'readonly' => ''.e($readonly).'','required' => 'true','type' => 'date']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('inputs.input-text-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'anho','name' => 'anho','label' => 'Año','item' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($modelo?->anho),'readonly' => ''.e($readonly).'','required' => 'true','type' => 'date']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale5c175f804af24f9bffe6a91552355f3)): ?>
<?php $attributes = $__attributesOriginale5c175f804af24f9bffe6a91552355f3; ?>
<?php unset($__attributesOriginale5c175f804af24f9bffe6a91552355f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale5c175f804af24f9bffe6a91552355f3)): ?>
<?php $component = $__componentOriginale5c175f804af24f9bffe6a91552355f3; ?>
<?php unset($__componentOriginale5c175f804af24f9bffe6a91552355f3); ?>
<?php endif; ?>
        </div>

        <!-- Marca -->
        <div class="col-span-12 md:col-span-6">
            <label for="marca_id" class="block text-sm font-medium text-gray-700">
                Marca
            </label>
            <select
                id="marca_id"
                name="marca_id"
                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                <?php echo e($readonly ? 'disabled' : ''); ?>

                required>
                <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($marca->id); ?>" <?php echo e($modelo?->marca_id == $marca->id ? 'selected' : ''); ?>>
                        <?php echo e($marca->nombre); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Imagen -->
        <div class="col-span-12 md:col-span-6">
            <?php if (isset($component)) { $__componentOriginal50f7405e0239b8ce9a4e5c10b419bc6c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal50f7405e0239b8ce9a4e5c10b419bc6c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.input-file-label','data' => ['id' => 'imagen','name' => 'imagen','label' => 'Imagen','readonly' => ''.e($readonly).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('inputs.input-file-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'imagen','name' => 'imagen','label' => 'Imagen','readonly' => ''.e($readonly).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal50f7405e0239b8ce9a4e5c10b419bc6c)): ?>
<?php $attributes = $__attributesOriginal50f7405e0239b8ce9a4e5c10b419bc6c; ?>
<?php unset($__attributesOriginal50f7405e0239b8ce9a4e5c10b419bc6c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal50f7405e0239b8ce9a4e5c10b419bc6c)): ?>
<?php $component = $__componentOriginal50f7405e0239b8ce9a4e5c10b419bc6c; ?>
<?php unset($__componentOriginal50f7405e0239b8ce9a4e5c10b419bc6c); ?>
<?php endif; ?>
        </div>

        <!-- Mostrar imagen o placeholder -->
        <div class="col-span-12 md:col-span-12 text-center mt-4">
            <img
                title="<?php echo e($modelo?->nombre ?? 'Imagen no disponible'); ?>"
                class="object-scale-down h-32 w-32 mx-auto rounded-md border"
                src="<?php echo e(!empty($modelo?->imagen)
                    ? route('images.show', ['fileType' => 'modelos', 'fileName' => basename($modelo->imagen)])
                    : asset('storage/imagenes/placeholder.png')); ?>"
                alt="Imagen del modelo">
        </div>

        <!-- Descontinuado -->
        <div class="col-span-12 md:col-span-12">
            <?php if (isset($component)) { $__componentOriginalf843b523e2374c0bf28615a39e86f2fe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf843b523e2374c0bf28615a39e86f2fe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.input-checkbox-label','data' => ['id' => 'descontinuado','name' => 'descontinuado','label' => 'Descontinuado','item' => $modelo?->descontinuado,'readonly' => ''.e($readonly).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('inputs.input-checkbox-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'descontinuado','name' => 'descontinuado','label' => 'Descontinuado','item' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($modelo?->descontinuado),'readonly' => ''.e($readonly).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf843b523e2374c0bf28615a39e86f2fe)): ?>
<?php $attributes = $__attributesOriginalf843b523e2374c0bf28615a39e86f2fe; ?>
<?php unset($__attributesOriginalf843b523e2374c0bf28615a39e86f2fe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf843b523e2374c0bf28615a39e86f2fe)): ?>
<?php $component = $__componentOriginalf843b523e2374c0bf28615a39e86f2fe; ?>
<?php unset($__componentOriginalf843b523e2374c0bf28615a39e86f2fe); ?>
<?php endif; ?>
        </div>

        <!-- Botón Guardar -->
        <?php if($submit): ?>
            <div class="col-span-12 text-right p-1 bg-gray-300">
                <?php if (isset($component)) { $__componentOriginald35551f259f35ab190c68b8ec9ad5876 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald35551f259f35ab190c68b8ec9ad5876 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.button-form-save','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buttons.button-form-save'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Guardar <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald35551f259f35ab190c68b8ec9ad5876)): ?>
<?php $attributes = $__attributesOriginald35551f259f35ab190c68b8ec9ad5876; ?>
<?php unset($__attributesOriginald35551f259f35ab190c68b8ec9ad5876); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald35551f259f35ab190c68b8ec9ad5876)): ?>
<?php $component = $__componentOriginald35551f259f35ab190c68b8ec9ad5876; ?>
<?php unset($__componentOriginald35551f259f35ab190c68b8ec9ad5876); ?>
<?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\hugom\Documents\DWES-Hugo-Moruno\Laravel\aprende03\proyectos\ConcesionarioApp\resources\views/admin/modelo/partials/form.blade.php ENDPATH**/ ?>