<div class="flex justify-between my-3">
    <h3 class="text-lg font-bold mb-4">Lista de Usuarios</h3>
</div>
<?php if($usuarios->isEmpty()): ?>
    <p>No hay usuarios registrados.</p>
<?php else: ?>
    <table class="table-auto w-full border-collapse border border-gray-300">
        <thead>
        <tr class="bg-gray-100">
            <th class="border border-gray-300 px-4 py-2">ID</th>
            <th class="border border-gray-300 px-4 py-2">Nombre</th>
            <th class="border border-gray-300 px-4 py-2">Email</th>
            <th class="border border-gray-300 px-4 py-2">Role</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border border-gray-300">
                <td class="px-4 py-2 text-center"><?php echo e($usuario->id); ?></td>
                <td class="px-4 py-2"><?php echo e($usuario->name); ?></td>
                <td class="px-4 py-2"><?php echo e($usuario->email); ?></td>
                <td class="px-4 py-2 text-center"><?php echo e($usuario->getRoleNames()); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php endif; ?>
<?php /**PATH C:\Users\hugom\Documents\DWES-Hugo-Moruno\Laravel\aprende03\proyectos\ConcesionarioApp\resources\views/admin/usuarios/list.blade.php ENDPATH**/ ?>