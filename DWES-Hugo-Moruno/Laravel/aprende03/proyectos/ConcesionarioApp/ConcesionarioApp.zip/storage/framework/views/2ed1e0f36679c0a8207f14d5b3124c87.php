<button type="button" class="bg-cyan-400 hover:bg-cyan-100 rounded px-3 py-1 mx-1 text-white">
    <i class="fa-solid fa-eye"></i>
</button>

<?php /**PATH C:\Users\hugom\Documents\DWES-Hugo-Moruno\Laravel\aprende03\proyectos\ConcesionarioApp\resources\views/components/buttons/button-show.blade.php ENDPATH**/ ?>