<style>
    td, th
    {
        padding: 10px 0;
    }
    #modelos:nth-child(even)
    {
        background-color: lightblue;
    }
</style>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="container mx-auto">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight flex justify-between items-center">
                <?php echo e(__('Listado de Marcas')); ?>

                <?php if (\Illuminate\Support\Facades\Blade::check('role', 'ADMIN')): ?>
                <a href="<?php echo e(route('admin.marcas.index')); ?>">
                    <?php if (isset($component)) { $__componentOriginald148e865c5ac24c5be2edcd9c222cd9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald148e865c5ac24c5be2edcd9c222cd9d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.button-edit','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buttons.button-edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald148e865c5ac24c5be2edcd9c222cd9d)): ?>
<?php $attributes = $__attributesOriginald148e865c5ac24c5be2edcd9c222cd9d; ?>
<?php unset($__attributesOriginald148e865c5ac24c5be2edcd9c222cd9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald148e865c5ac24c5be2edcd9c222cd9d)): ?>
<?php $component = $__componentOriginald148e865c5ac24c5be2edcd9c222cd9d; ?>
<?php unset($__componentOriginald148e865c5ac24c5be2edcd9c222cd9d); ?>
<?php endif; ?>
                </a>
                <?php endif; ?>
            </h2>
        </div>
     <?php $__env->endSlot(); ?>
    <div class="py-12">
        <div class="container mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <?php if($marcas->isEmpty()): ?>
                    <p>No hay marcas registradas.</p>
                <?php else: ?>
                <table class="table table-bordered w-full p-4">
                    <thead>
                        <tr>
                            <th class="text-left ps-3" >#</th>
                            <th>Nombre</th>
                            <th>País de Origen</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="bg-blue-300 font-extrabold">
                            <td class="ps-3"><?php echo e($marca->id); ?></td>
                            <td><?php echo e($marca->nombre); ?></td>
                            <td><?php echo e($marca->pais_origen); ?></td>
                            <td></td>
                        </tr>
                        <tr class="bg-blue-50 font-extrabold">
                            <td colspan="4" class="ps-3">Modelos</td>
                        </tr>
                        <?php $__currentLoopData = $modelos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($modelo->marca_id == $marca->id ): ?>
                                <tr class="bg-blue-100" id="modelos">
                                    <td class="text-center"><?php echo e($modelo->identificador); ?>  -  <?php echo e($modelo->año); ?></td>
                                    <td><?php echo e($modelo->nombre); ?></td>
                                    <td><?php echo e($modelo->tipo); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('modelo',$modelo->identificador)); ?>" class="w-full h-full">
                                            <?php if (isset($component)) { $__componentOriginal15cbcf6df9a381f49a6765504e457949 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal15cbcf6df9a381f49a6765504e457949 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.button-show','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buttons.button-show'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal15cbcf6df9a381f49a6765504e457949)): ?>
<?php $attributes = $__attributesOriginal15cbcf6df9a381f49a6765504e457949; ?>
<?php unset($__attributesOriginal15cbcf6df9a381f49a6765504e457949); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal15cbcf6df9a381f49a6765504e457949)): ?>
<?php $component = $__componentOriginal15cbcf6df9a381f49a6765504e457949; ?>
<?php unset($__componentOriginal15cbcf6df9a381f49a6765504e457949); ?>
<?php endif; ?>
                                        </a>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

</div>
</body>
</html>
<?php /**PATH C:\Users\hugom\Documents\DWES-Hugo-Moruno\Laravel\aprende03\proyectos\ConcesionarioApp\resources\views/marcas/index.blade.php ENDPATH**/ ?>