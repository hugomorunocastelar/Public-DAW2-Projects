<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="text-center" style="font-size: 25px">
            <?php echo e(__('Bienvenido a nuestro concesionario!')); ?>

        </div>
     <?php $__env->endSlot(); ?>
    <main class="container mx-auto sm:px-6 lg:px-8">
        <section id="bannerCochesPortadas">
            <div id="divCochesPortadas">
                <div id="textoCochesPortadas">
                    <h2 class="text-xl mb-3 pe-10">Descubre el nuevo Opel Corsa: el equilibrio perfecto entre diseño y rendimiento!</h2>
                    <h4 class="pe-10">Conducir nunca había sido tan emocionante. ¡Pruébalo hoy!</h4>
                </div>
                <img id="imgCochesPortadas" src="<?php echo e(asset('/storage/coches/coche1.jpg')); ?>" alt="">
            </div>
        </section>
        <section id="bannerCochesPortadas">
            <div id="divCochesPortadas">
                <img id="imgCochesPortadas" src="<?php echo e(asset('/storage/coches/coche2.jpeg')); ?>" alt="">
                <div id="textoCochesPortadas">
                    <h2 class="text-xl mb-3 ps-10">El SUV definitivo: estilo, confort y tecnología en un solo vehículo!</h2>
                    <h4 class="ps-16">Disponible en nuestro concesionario de Badajoz. ¡Ven a verlo!</h4>
                </div>
            </div>
        </section>
        <section id="bannerCochesPortadas">
            <div id="divCochesPortadas">
                <div id="textoCochesPortadas">
                    <h2 class="text-xl mb-3 pe-10">Innovación a tu alcance: el nuevo Seat Arona ya está aquí!</h2>
                    <h4 class="pe-10">Ven y experimenta su dinamismo y confort en nuestras instalaciones!</h4>
                </div>
                <img id="imgCochesPortadas" src="<?php echo e(url('/storage/coches/coche3.jpg')); ?>" alt="">
            </div>
        </section>
        <section id="bannerCochesPortadas">
            <div id="divCochesPortadas">
                <img id="imgCochesPortadas" src="<?php echo e(url('/storage/coches/coche4.png')); ?>" alt="">
                <div id="textoCochesPortadas">
                    <h2 class="text-xl mb-3 ps-10">Compacto, elegante y potente: el Opel Astra redefine la conducción urbana!</h2>
                    <h4 class="ps-10">Consulta nuestras promociones especiales por tiempo limitado!</h4>
                </div>
            </div>
        </section>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\hugom\Documents\DWES-Hugo-Moruno\Laravel\aprende03\proyectos\ConcesionarioApp\resources\views/welcome.blade.php ENDPATH**/ ?>