<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="text-center">
            <?php echo e(__('Administrar Clientes')); ?>

        </div>
     <?php $__env->endSlot(); ?>

    <div class="container mx-auto px-8 py-4">
        <div class="bg-gray-200 rounded-lg shadow-lg p-4 mb-6 flex justify-between">
            <h1 class="text-2xl font-bold text-blue-900 mb-4">Lista de Clientes</h1>
            <a href="<?php echo e(route('admin.clientes.create')); ?>">
                <?php if (isset($component)) { $__componentOriginal17363919ac41f4f2634b43bffeccf06b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal17363919ac41f4f2634b43bffeccf06b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.button-add','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buttons.button-add'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal17363919ac41f4f2634b43bffeccf06b)): ?>
<?php $attributes = $__attributesOriginal17363919ac41f4f2634b43bffeccf06b; ?>
<?php unset($__attributesOriginal17363919ac41f4f2634b43bffeccf06b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal17363919ac41f4f2634b43bffeccf06b)): ?>
<?php $component = $__componentOriginal17363919ac41f4f2634b43bffeccf06b; ?>
<?php unset($__componentOriginal17363919ac41f4f2634b43bffeccf06b); ?>
<?php endif; ?>
            </a>
        </div>

        <div class="bg-white rounded-lg shadow-lg overflow-hidden">
            <table class="w-full border-collapse">
                <thead class="bg-gray-300">
                <tr>
                    <th class="px-4 py-2 text-left text-sm font-semibold text-blue-900">Nombre</th>
                    <th class="px-4 py-2 text-left text-sm font-semibold text-blue-900">Email</th>
                    <th class="px-4 py-2 text-left text-sm font-semibold text-blue-900">Teléfono</th>
                    <th class="px-4 py-2 text-left text-sm font-semibold text-blue-900">Dirección</th>
                    <th class="px-4 py-2 text-left text-sm font-semibold text-blue-900">Acciones</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-gray-100">
                        <td class="px-4 py-2 border-t text-sm text-gray-700"><?php echo e($cliente->nombre); ?></td>
                        <td class="px-4 py-2 border-t text-sm text-gray-700"><?php echo e($cliente->email); ?></td>
                        <td class="px-4 py-2 border-t text-sm text-gray-700"><?php echo e($cliente->telefono); ?></td>
                        <td class="px-4 py-2 border-t text-sm text-gray-700"><?php echo e($cliente->direccion); ?></td>
                        <td class="px-4 py-2 border-t text-sm text-gray-700 flex space-x-2">
                            <a href="<?php echo e(route('admin.clientes.show', $cliente->id)); ?>"
                               class="px-3 py-1 bg-blue-500 text-white rounded text-xs hover:bg-blue-600">
                                Ver
                            </a>
                            <a href="<?php echo e(route('admin.clientes.edit', $cliente->id)); ?>"
                               class="px-3 py-1 bg-yellow-500 text-white rounded text-xs hover:bg-yellow-600">
                                Editar
                            </a>
                            <form action="<?php echo e(route('admin.clientes.destroy', $cliente->id)); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                        class="px-3 py-1 bg-red-500 text-white rounded text-xs hover:bg-red-600">
                                    Eliminar
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\hugom\Documents\DWES-Hugo-Moruno\Laravel\aprende03\proyectos\ConcesionarioApp\resources\views/admin/clientes/index.blade.php ENDPATH**/ ?>