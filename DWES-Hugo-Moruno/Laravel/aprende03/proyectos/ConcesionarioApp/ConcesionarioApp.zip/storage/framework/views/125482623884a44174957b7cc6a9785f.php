<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['marca' => null, 'submit' => true, 'readonly' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['marca' => null, 'submit' => true, 'readonly' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="mx-auto px-8">
    <div class="w-full border p-4 bg-white shadow-lg rounded-lg grid grid-cols-12 gap-4">
        <!-- Título -->
        <div class="col-span-12 p-2 bg-gray-300 uppercase tracking-widest font-semibold text-lg text-center">
            <?php echo e($marca?->nombre ?? 'Registrar una nueva marca'); ?>

        </div>

        <!-- Campo: Nombre -->
        <div class="col-span-12 md:col-span-6">
            <?php if (isset($component)) { $__componentOriginale5c175f804af24f9bffe6a91552355f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale5c175f804af24f9bffe6a91552355f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.input-text-label','data' => ['id' => 'nombre','name' => 'nombre','label' => 'Nombre','item' => $marca?->nombre,'readonly' => ''.e($readonly).'','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('inputs.input-text-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'nombre','name' => 'nombre','label' => 'Nombre','item' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($marca?->nombre),'readonly' => ''.e($readonly).'','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale5c175f804af24f9bffe6a91552355f3)): ?>
<?php $attributes = $__attributesOriginale5c175f804af24f9bffe6a91552355f3; ?>
<?php unset($__attributesOriginale5c175f804af24f9bffe6a91552355f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale5c175f804af24f9bffe6a91552355f3)): ?>
<?php $component = $__componentOriginale5c175f804af24f9bffe6a91552355f3; ?>
<?php unset($__componentOriginale5c175f804af24f9bffe6a91552355f3); ?>
<?php endif; ?>
        </div>

        <!-- Campo: País de Origen -->
        <div class="col-span-12 md:col-span-6">
            <?php if (isset($component)) { $__componentOriginale5c175f804af24f9bffe6a91552355f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale5c175f804af24f9bffe6a91552355f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.input-text-label','data' => ['id' => 'pais_origen','name' => 'pais_origen','label' => 'País de Origen','item' => $marca?->pais_origen,'readonly' => ''.e($readonly).'','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('inputs.input-text-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'pais_origen','name' => 'pais_origen','label' => 'País de Origen','item' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($marca?->pais_origen),'readonly' => ''.e($readonly).'','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale5c175f804af24f9bffe6a91552355f3)): ?>
<?php $attributes = $__attributesOriginale5c175f804af24f9bffe6a91552355f3; ?>
<?php unset($__attributesOriginale5c175f804af24f9bffe6a91552355f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale5c175f804af24f9bffe6a91552355f3)): ?>
<?php $component = $__componentOriginale5c175f804af24f9bffe6a91552355f3; ?>
<?php unset($__componentOriginale5c175f804af24f9bffe6a91552355f3); ?>
<?php endif; ?>
        </div>

        <!-- Campo: Imagen -->
        <div class="col-span-12 md:col-span-12">
            <?php if (isset($component)) { $__componentOriginal50f7405e0239b8ce9a4e5c10b419bc6c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal50f7405e0239b8ce9a4e5c10b419bc6c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.input-file-label','data' => ['id' => 'imagen','name' => 'imagen','label' => 'Imagen','readonly' => ''.e($readonly).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('inputs.input-file-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'imagen','name' => 'imagen','label' => 'Imagen','readonly' => ''.e($readonly).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal50f7405e0239b8ce9a4e5c10b419bc6c)): ?>
<?php $attributes = $__attributesOriginal50f7405e0239b8ce9a4e5c10b419bc6c; ?>
<?php unset($__attributesOriginal50f7405e0239b8ce9a4e5c10b419bc6c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal50f7405e0239b8ce9a4e5c10b419bc6c)): ?>
<?php $component = $__componentOriginal50f7405e0239b8ce9a4e5c10b419bc6c; ?>
<?php unset($__componentOriginal50f7405e0239b8ce9a4e5c10b419bc6c); ?>
<?php endif; ?>

            <!-- Mostrar imagen (o placeholder si no hay imagen) -->
            <div class="mt-4 text-center">
                <img
                    title="<?php echo e($marca?->nombre ?? 'Imagen no disponible'); ?>"
                    class="object-scale-down h-32 w-32 mx-auto rounded-md border"
                    src="<?php echo e(!empty($marca?->imagen)
                    ? route('images.show', ['fileType' => 'marcas', 'fileName' => basename($marca->imagen)])
                    : asset('storage/imagenes/placeholder.png')); ?>"
                    alt="Imagen de la marca">

            </div>
        </div>

        <!-- Botón Guardar -->
        <?php if($submit): ?>
            <div class="col-span-12 text-right p-2 bg-gray-300">
                <?php if (isset($component)) { $__componentOriginald35551f259f35ab190c68b8ec9ad5876 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald35551f259f35ab190c68b8ec9ad5876 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.button-form-save','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buttons.button-form-save'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    Guardar
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald35551f259f35ab190c68b8ec9ad5876)): ?>
<?php $attributes = $__attributesOriginald35551f259f35ab190c68b8ec9ad5876; ?>
<?php unset($__attributesOriginald35551f259f35ab190c68b8ec9ad5876); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald35551f259f35ab190c68b8ec9ad5876)): ?>
<?php $component = $__componentOriginald35551f259f35ab190c68b8ec9ad5876; ?>
<?php unset($__componentOriginald35551f259f35ab190c68b8ec9ad5876); ?>
<?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\hugom\Documents\DWES-Hugo-Moruno\Laravel\aprende03\proyectos\ConcesionarioApp\resources\views/admin/marcas/partials/form.blade.php ENDPATH**/ ?>