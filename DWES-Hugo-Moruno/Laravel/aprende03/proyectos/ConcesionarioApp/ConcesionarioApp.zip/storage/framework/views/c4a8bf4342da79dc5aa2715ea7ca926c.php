<div class="flex justify-between my-3">
    <h3 class="text-lg font-bold mb-4">Lista de Modelos</h3>
    <a href="<?php echo e(route('admin.modelos.index')); ?>">
        <?php if (isset($component)) { $__componentOriginald148e865c5ac24c5be2edcd9c222cd9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald148e865c5ac24c5be2edcd9c222cd9d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.button-edit','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buttons.button-edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald148e865c5ac24c5be2edcd9c222cd9d)): ?>
<?php $attributes = $__attributesOriginald148e865c5ac24c5be2edcd9c222cd9d; ?>
<?php unset($__attributesOriginald148e865c5ac24c5be2edcd9c222cd9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald148e865c5ac24c5be2edcd9c222cd9d)): ?>
<?php $component = $__componentOriginald148e865c5ac24c5be2edcd9c222cd9d; ?>
<?php unset($__componentOriginald148e865c5ac24c5be2edcd9c222cd9d); ?>
<?php endif; ?>
    </a>
</div>
<?php if($modelos->isEmpty()): ?>
    <p>No hay modelos registrados.</p>
<?php else: ?>
    <table class="table-auto w-full border-collapse border border-gray-300">
        <thead>
        <tr class="bg-gray-100">
            <th class="border border-gray-300 px-4 py-2">ID</th>
            <th class="border border-gray-300 px-4 py-2">Nombre</th>
            <th class="border border-gray-300 px-4 py-2">Tipo</th>
            <th class="border border-gray-300 px-4 py-2">Año</th>
            <th class="border border-gray-300 px-4 py-2">Marca</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $modelos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border border-gray-300">
                <td class="px-4 py-2 text-center"><?php echo e($modelo->identificador); ?></td>
                <td class="px-4 py-2"><?php echo e($modelo->nombre); ?></td>
                <td class="px-4 py-2"><?php echo e($modelo->tipo); ?></td>
                <td class="px-4 py-2"><?php echo e($modelo->anho); ?></td>
                <td class="px-4 py-2"><?php echo e($modelo->marca ? $modelo->marca->nombre : 'Marca no disponible'); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php endif; ?>
<?php /**PATH C:\Users\hugom\Documents\DWES-Hugo-Moruno\Laravel\aprende03\proyectos\ConcesionarioApp\resources\views/admin/modelo/partials/list.blade.php ENDPATH**/ ?>