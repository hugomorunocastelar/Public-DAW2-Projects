<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Get a Car')); ?></title>

        <link rel="shortcut icon" href="storage/logo/logo.png" type="image/x-icon">

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

        <!-- Styles -->
        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    </head>
    <body class="font-sans antialiased">
        <div class="flex flex-col min-h-screen bg-gray-100">

            <?php if (isset($component)) { $__componentOriginal5630d3d67c5d3d8fcd4724ecaa7a3c86 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5630d3d67c5d3d8fcd4724ecaa7a3c86 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.menus.menu-main','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menus.menu-main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5630d3d67c5d3d8fcd4724ecaa7a3c86)): ?>
<?php $attributes = $__attributesOriginal5630d3d67c5d3d8fcd4724ecaa7a3c86; ?>
<?php unset($__attributesOriginal5630d3d67c5d3d8fcd4724ecaa7a3c86); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5630d3d67c5d3d8fcd4724ecaa7a3c86)): ?>
<?php $component = $__componentOriginal5630d3d67c5d3d8fcd4724ecaa7a3c86; ?>
<?php unset($__componentOriginal5630d3d67c5d3d8fcd4724ecaa7a3c86); ?>
<?php endif; ?>

            <!-- Page Heading -->
            <?php if(isset($header)): ?>
                <header class="bg-white shadow">
                    <div class="container mx-auto py-6 sm:px-6 lg:px-8">
                        <?php echo e($header); ?>

                    </div>
                </header>
            <?php endif; ?>

            <!-- Page Content -->
            <main class="flex-grow">
                <?php echo e($slot); ?>

            </main>

            <footer class="bg-gray-50">
                <header class="bg-white shadow">
                    <div class="container mx-auto py-6 sm:px-6 lg:px-8">
                        <div class="flex justify-between text-gray-500">
                            <div>
                                <a href="<?php echo e(route('policy')); ?>" class="me-4">
                                    <?php echo e(__('Políticas')); ?>

                                </a>
                                <a href="<?php echo e(route('terms')); ?>">
                                    <?php echo e(__('Términos')); ?>

                                </a>
                            </div>
                            <div>
                                <h4>Hugo Moruno Parra 2024</h4>
                            </div>
                        </div>
                    </div>
                </header>
            </footer>

        </div>

        <?php echo $__env->yieldPushContent('modals'); ?>

        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    </body>
</html>
<?php /**PATH C:\Users\hugom\Documents\DWES-Hugo-Moruno\Laravel\aprende03\proyectos\ConcesionarioApp\resources\views/layouts/app.blade.php ENDPATH**/ ?>