<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="container mx-auto">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Administración')); ?>

            </h2>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-5">
        <div class="container mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-6" x-data="{
                tab: sessionStorage.getItem('lastTab') || 'clientes',
                setTab(tabName) {
                    this.tab = tabName;
                    sessionStorage.setItem('lastTab', tabName);
                }
            }">
                <div class="flex space-x-4 border-b pb-2">
                    <button
                        @click="setTab('clientes')"
                        :class="{ 'border-b-2 border-blue-500 text-blue-500': tab === 'clientes' }"
                        class="px-4 py-2 text-gray-700 hover:text-blue-500 focus:outline-none"
                    >
                        Clientes
                    </button>
                    <button
                        @click="setTab('coches')"
                        :class="{ 'border-b-2 border-blue-500 text-blue-500': tab === 'coches' }"
                        class="px-4 py-2 text-gray-700 hover:text-blue-500 focus:outline-none"
                    >
                        Coches
                    </button>
                    <button
                        @click="setTab('modelos')"
                        :class="{ 'border-b-2 border-blue-500 text-blue-500': tab === 'modelos' }"
                        class="px-4 py-2 text-gray-700 hover:text-blue-500 focus:outline-none"
                    >
                        Modelos
                    </button>
                    <button
                        @click="setTab('marcas')"
                        :class="{ 'border-b-2 border-blue-500 text-blue-500': tab === 'marcas' }"
                        class="px-4 py-2 text-gray-700 hover:text-blue-500 focus:outline-none"
                    >
                        Marcas
                    </button>
                    <button
                        @click="setTab('usuarios')"
                        :class="{ 'border-b-2 border-blue-500 text-blue-500': tab === 'usuarios' }"
                        class="px-4 py-2 text-gray-700 hover:text-blue-500 focus:outline-none"
                    >
                        Usuarios
                    </button>
                </div>

                <div class="mt-4">
                    <div x-show="tab === 'clientes'" class="p-4">
                        <?php echo $__env->make('admin.clientes.partials.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>

                    <div x-show="tab === 'coches'" class="p-4">
                        <?php echo $__env->make('admin.coches.partials.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>

                    <div x-show="tab === 'modelos'" class="p-4">
                        <?php echo $__env->make('admin.modelo.partials.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>

                    <div x-show="tab === 'marcas'" class="p-4">
                        <?php echo $__env->make('admin.marcas.partials.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>

                    <div x-show="tab === 'usuarios'" class="p-4">
                        <?php echo $__env->make('admin.usuarios.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\hugom\Documents\DWES-Hugo-Moruno\Laravel\aprende03\proyectos\ConcesionarioApp\resources\views/admin/index.blade.php ENDPATH**/ ?>