<button type="button" class="bg-blue-600 hover:bg-blue-400 text-white w-10 h-10 rounded">
    <i class="fa-regular fa-pen-to-square w-full"></i>
</button>
