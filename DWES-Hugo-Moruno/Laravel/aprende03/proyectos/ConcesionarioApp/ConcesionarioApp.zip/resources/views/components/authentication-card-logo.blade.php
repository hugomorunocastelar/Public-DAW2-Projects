<a href="/">
    <img src="/storage/logo/logo.png" alt="Logo de la aplicación" style="height: 100px">
</a>
