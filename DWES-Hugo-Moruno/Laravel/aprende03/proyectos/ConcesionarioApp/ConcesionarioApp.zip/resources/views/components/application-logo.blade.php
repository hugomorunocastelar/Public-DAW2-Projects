<img src="/storage/logo/logo-brand.png" alt="Logo de la aplicación" style="height: 35px">
