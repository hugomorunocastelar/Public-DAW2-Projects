@props(['slot' => 'Guardar'])

<button class='bg-cyan-400 hover:bg-cyan-100 rounded'>
    <p>{{$slot}}</p>
</button>
