{{-- resources/views/clientes/mis-viajes.blade.php --}}

@extends('layouts.app')

@section('title', 'Mis Viajes')

@section('content')
    <div class="container mt-4">
        <h1 class="mb-4">Mis Viajes</h1>


        <p>Viajes reservados</p>
    </div>
@endsection
