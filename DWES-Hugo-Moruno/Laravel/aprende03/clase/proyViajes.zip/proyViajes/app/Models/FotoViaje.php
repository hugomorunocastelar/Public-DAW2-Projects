<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FotoViaje extends Model
{
    //
}
