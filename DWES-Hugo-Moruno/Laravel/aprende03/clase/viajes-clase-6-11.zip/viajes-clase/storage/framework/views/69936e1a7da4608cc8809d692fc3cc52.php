<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <!-- Styles -->
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>
<body class="font-sans antialiased">

<div class="min-h-screen bg-gray-100">

    <?php if (isset($component)) { $__componentOriginal1e9f4a9c279057ccaa6afdf4bd12a632 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1e9f4a9c279057ccaa6afdf4bd12a632 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.menus.menu-admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menus.menu-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1e9f4a9c279057ccaa6afdf4bd12a632)): ?>
<?php $attributes = $__attributesOriginal1e9f4a9c279057ccaa6afdf4bd12a632; ?>
<?php unset($__attributesOriginal1e9f4a9c279057ccaa6afdf4bd12a632); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1e9f4a9c279057ccaa6afdf4bd12a632)): ?>
<?php $component = $__componentOriginal1e9f4a9c279057ccaa6afdf4bd12a632; ?>
<?php unset($__componentOriginal1e9f4a9c279057ccaa6afdf4bd12a632); ?>
<?php endif; ?>

    <header>
        <!-- Page Heading -->
        <?php if(isset($header)): ?>
            <header class="bg-white shadow">
                <div class="mx-auto py-6 px-4 sm:px-6 lg:px-8">
                    <?php echo e($header); ?>

                </div>
            </header>
        <?php endif; ?>

        
        
    </header>

    <!-- Page Content -->
    <main>
        <?php echo e($slot); ?>

    </main>
</div>

<?php echo $__env->yieldPushContent('modals'); ?>

<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>
</html>
<?php /**PATH C:\Users\daw2\Desktop\viajes-clase\resources\views/layouts/app.blade.php ENDPATH**/ ?>