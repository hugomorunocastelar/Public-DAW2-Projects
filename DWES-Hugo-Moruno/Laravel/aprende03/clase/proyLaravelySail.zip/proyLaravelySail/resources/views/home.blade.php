<x-app-layout>
    <x-slot name="header">

    </x-slot>
</x-app-layout>
