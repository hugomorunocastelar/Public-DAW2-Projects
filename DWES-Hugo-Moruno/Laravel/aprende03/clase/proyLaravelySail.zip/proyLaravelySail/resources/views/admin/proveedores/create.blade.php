<x-app-layout>
    <x-slot name="header">
        Administración de artículos
    </x-slot>

    <div class="m-4 p-8">
        <form action="{{route('admin.proveedores.store')}}}" method="post">
            <x-buttons.save-form title="Guardar"/>
        </form>
    </div>
</x-app-layout>
