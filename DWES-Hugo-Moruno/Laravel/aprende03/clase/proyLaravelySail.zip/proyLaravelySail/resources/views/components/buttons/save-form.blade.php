@props(['title'=>'Guardar'])
<button class="bg-indigo-400 px-1 text-xs rounded uppercase border border-indigo-800 hover:bg-indigo-200">
    {{ $title }}
</button>
