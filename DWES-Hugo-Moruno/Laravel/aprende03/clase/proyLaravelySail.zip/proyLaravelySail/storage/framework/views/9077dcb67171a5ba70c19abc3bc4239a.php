<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        Administración de artículos
     <?php $__env->endSlot(); ?>
    <a href="<?php echo e(route('admin.proveedores.create')); ?>"
       class="border-2 border-amber-800"> <?php if (isset($component)) { $__componentOriginal78d8734e4b0eac380ba95e5a2785c4ed = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal78d8734e4b0eac380ba95e5a2785c4ed = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.new','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buttons.new'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal78d8734e4b0eac380ba95e5a2785c4ed)): ?>
<?php $attributes = $__attributesOriginal78d8734e4b0eac380ba95e5a2785c4ed; ?>
<?php unset($__attributesOriginal78d8734e4b0eac380ba95e5a2785c4ed); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal78d8734e4b0eac380ba95e5a2785c4ed)): ?>
<?php $component = $__componentOriginal78d8734e4b0eac380ba95e5a2785c4ed; ?>
<?php unset($__componentOriginal78d8734e4b0eac380ba95e5a2785c4ed); ?>
<?php endif; ?> </a>

    <div class="m-4 p-8 rounded shadow bg-amber-200 border-4 border-b-gray-600">
        PROVEEDORES:
        <br/>
        Empresas:
        <br><br>
        <table class="table-auto border-separate border-spacing-4 w-full border border-gray-400">
            <thead class="bg-gray-100">
            <tr>
                <th class="w-1/6 border p-2">NIF</th>
                <th class="w-1/6 border p-2">Razón Social</th>
                <th class="w-1/6 border p-2">Denominación</th>
                <th class="w-3/6 border p-2">Comentario</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proveedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($proveedor->autonomo): ?>
                    <tr>
                        <td class="border p-2"><?php echo e($proveedor->nif); ?></td>
                        <td class="border p-2"><?php echo e($proveedor->razonSocial); ?></td>
                        <td class="border p-2"><?php echo e($proveedor->denominacion); ?></td>
                        <td class="border p-2"><?php echo e($proveedor->comentario); ?></td>
                        <td>
                            <?php if (isset($component)) { $__componentOriginald76090497b7150ad0ecaa5b8e0f8e589 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald76090497b7150ad0ecaa5b8e0f8e589 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.show-table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buttons.show-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald76090497b7150ad0ecaa5b8e0f8e589)): ?>
<?php $attributes = $__attributesOriginald76090497b7150ad0ecaa5b8e0f8e589; ?>
<?php unset($__attributesOriginald76090497b7150ad0ecaa5b8e0f8e589); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald76090497b7150ad0ecaa5b8e0f8e589)): ?>
<?php $component = $__componentOriginald76090497b7150ad0ecaa5b8e0f8e589; ?>
<?php unset($__componentOriginald76090497b7150ad0ecaa5b8e0f8e589); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalbbe3298341c76308e6fa0eca92afc2f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbbe3298341c76308e6fa0eca92afc2f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.edit-table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buttons.edit-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbbe3298341c76308e6fa0eca92afc2f6)): ?>
<?php $attributes = $__attributesOriginalbbe3298341c76308e6fa0eca92afc2f6; ?>
<?php unset($__attributesOriginalbbe3298341c76308e6fa0eca92afc2f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbbe3298341c76308e6fa0eca92afc2f6)): ?>
<?php $component = $__componentOriginalbbe3298341c76308e6fa0eca92afc2f6; ?>
<?php unset($__componentOriginalbbe3298341c76308e6fa0eca92afc2f6); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalcd3a6c592717d5bb869af67c43d069aa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd3a6c592717d5bb869af67c43d069aa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.delete-table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buttons.delete-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd3a6c592717d5bb869af67c43d069aa)): ?>
<?php $attributes = $__attributesOriginalcd3a6c592717d5bb869af67c43d069aa; ?>
<?php unset($__attributesOriginalcd3a6c592717d5bb869af67c43d069aa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd3a6c592717d5bb869af67c43d069aa)): ?>
<?php $component = $__componentOriginalcd3a6c592717d5bb869af67c43d069aa; ?>
<?php unset($__componentOriginalcd3a6c592717d5bb869af67c43d069aa); ?>
<?php endif; ?>
                        </td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <br>
        Autónomos:
        <br><br>
        <table class="table-auto border-separate border-spacing-4 w-full border border-gray-400">
            <thead class="bg-gray-100">
            <tr>
                <th class="w-1/4 border p-2">NIF</th>
                <th class="w-1/4 border p-2">Nombre y Apellidos</th>
                <th class="w-1/4 border p-2">Denominación</th>
                <th class="w-1/4 border p-2">Comentario</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proveedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!($proveedor->autonomo)): ?>
                    <tr>
                        <td class="border p-2"><?php echo e($proveedor->nif); ?></td>
                        <td class="border p-2"><?php echo e($proveedor->nombre); ?> <?php echo e($proveedor->apellido1); ?> <?php echo e($proveedor->apellido2); ?></td>
                        <td class="border p-2"><?php echo e($proveedor->denominacion); ?></td>
                        <td class="border p-2"><?php echo e($proveedor->comentario); ?></td>
                        <td>
                            <?php if (isset($component)) { $__componentOriginald76090497b7150ad0ecaa5b8e0f8e589 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald76090497b7150ad0ecaa5b8e0f8e589 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.show-table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buttons.show-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald76090497b7150ad0ecaa5b8e0f8e589)): ?>
<?php $attributes = $__attributesOriginald76090497b7150ad0ecaa5b8e0f8e589; ?>
<?php unset($__attributesOriginald76090497b7150ad0ecaa5b8e0f8e589); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald76090497b7150ad0ecaa5b8e0f8e589)): ?>
<?php $component = $__componentOriginald76090497b7150ad0ecaa5b8e0f8e589; ?>
<?php unset($__componentOriginald76090497b7150ad0ecaa5b8e0f8e589); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalbbe3298341c76308e6fa0eca92afc2f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbbe3298341c76308e6fa0eca92afc2f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.edit-table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buttons.edit-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbbe3298341c76308e6fa0eca92afc2f6)): ?>
<?php $attributes = $__attributesOriginalbbe3298341c76308e6fa0eca92afc2f6; ?>
<?php unset($__attributesOriginalbbe3298341c76308e6fa0eca92afc2f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbbe3298341c76308e6fa0eca92afc2f6)): ?>
<?php $component = $__componentOriginalbbe3298341c76308e6fa0eca92afc2f6; ?>
<?php unset($__componentOriginalbbe3298341c76308e6fa0eca92afc2f6); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalcd3a6c592717d5bb869af67c43d069aa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd3a6c592717d5bb869af67c43d069aa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.delete-table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buttons.delete-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd3a6c592717d5bb869af67c43d069aa)): ?>
<?php $attributes = $__attributesOriginalcd3a6c592717d5bb869af67c43d069aa; ?>
<?php unset($__attributesOriginalcd3a6c592717d5bb869af67c43d069aa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd3a6c592717d5bb869af67c43d069aa)): ?>
<?php $component = $__componentOriginalcd3a6c592717d5bb869af67c43d069aa; ?>
<?php unset($__componentOriginalcd3a6c592717d5bb869af67c43d069aa); ?>
<?php endif; ?>
                        </td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/admin/proveedores/index.blade.php ENDPATH**/ ?>