<x-app-layout>
    <x-slot name="header">
        <div class="text-center" style="font-size: 25px">
            {{ __('Bienvenido a Gestión de gastos!') }}
        </div>
    </x-slot>
    <main class="container mx-auto sm:px-6 lg:px-8">

    </main>
</x-app-layout>
