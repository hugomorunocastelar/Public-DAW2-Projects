<button type="button" class="bg-red-600 hover:bg-red-400 text-white w-10 h-10 rounded">
    <i class="fa-solid fa-trash w-full"></i>
</button>
