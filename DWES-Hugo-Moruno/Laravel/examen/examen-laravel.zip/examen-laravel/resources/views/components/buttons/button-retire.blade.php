<button type="button" class="bg-yellow-600 hover:bg-yellow-400 w-10 h-10 rounded">
    <i class="fa-solid fa-box w-full"></i>
</button>
