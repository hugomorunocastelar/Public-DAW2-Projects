<button type="button" class="bg-green-600 hover:bg-green-400 text-white w-10 h-10 rounded">
    <i class="fa-solid fa-plus w-full"></i>
</button>
<?php /**PATH C:\Users\daw2\Documents\DWES-Hugo-Moruno\Laravel\examen\examen-laravel\resources\views/components/buttons/button-add.blade.php ENDPATH**/ ?>