<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="text-center">
            <?php echo e(__('Administrar Gastos')); ?>

        </div>
     <?php $__env->endSlot(); ?>

    <div class="container mx-auto px-8 py-4">
        <div class="bg-gray-200 rounded-lg shadow-lg p-4 mb-6 flex justify-between">
            <h1 class="text-2xl font-bold text-blue-900 mb-4">Lista de Gastos</h1>
            <a href="<?php echo e(route('gastos.create')); ?>">
                <?php if (isset($component)) { $__componentOriginal17363919ac41f4f2634b43bffeccf06b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal17363919ac41f4f2634b43bffeccf06b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.button-add','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buttons.button-add'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal17363919ac41f4f2634b43bffeccf06b)): ?>
<?php $attributes = $__attributesOriginal17363919ac41f4f2634b43bffeccf06b; ?>
<?php unset($__attributesOriginal17363919ac41f4f2634b43bffeccf06b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal17363919ac41f4f2634b43bffeccf06b)): ?>
<?php $component = $__componentOriginal17363919ac41f4f2634b43bffeccf06b; ?>
<?php unset($__componentOriginal17363919ac41f4f2634b43bffeccf06b); ?>
<?php endif; ?>
            </a>
        </div>

        <div class="bg-white rounded-lg shadow-lg overflow-hidden">
            <?php echo $__env->make('admin.gastos.partials.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\daw2\Documents\DWES-Hugo-Moruno\Laravel\examen\examen-laravel\resources\views/admin/gastos/index.blade.php ENDPATH**/ ?>