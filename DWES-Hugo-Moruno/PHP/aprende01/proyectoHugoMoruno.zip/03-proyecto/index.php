<?php

    require_once "TraficoController.php";

    new TraficoController();