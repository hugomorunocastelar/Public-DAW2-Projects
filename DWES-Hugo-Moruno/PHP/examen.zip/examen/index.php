<?php

require_once "HabitacionController.php";

new HabitacionController();