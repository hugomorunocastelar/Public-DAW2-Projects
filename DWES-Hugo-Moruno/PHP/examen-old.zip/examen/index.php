<?php

require_once "CurriculoController.php";

new CurriculoController();